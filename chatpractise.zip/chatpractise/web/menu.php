<?php

$TOP = '
<div style="width: 100%; background-color: '.$COLORS[0].'; height: 50px;">
	<table class="top_tab">
		<tr>
			<td><a href="/" class="t33" style="text-decoration: none;">Forums</a></td>
			<td></td>
		</tr>
	</table>
</div>
';

?>