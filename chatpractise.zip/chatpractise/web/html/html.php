<?php

$HTML .= '
<!DOCTYPE html>
<html lang="lv">
<head>
	<meta charset="UTF-8">
	<title>Čats</title>
	<link rel="stylesheet" href="web/css/main.css">
	<style>
		margin: 0px;
		'.$STYLE.'
	</style>
	<script src="web/js/main.js"></script>
</head>
<body>
	<div>'.$TOP.'</div>
			'.$INSERT.'
</body>
</html>
';


?>